# phil welsby - 13 jan2021

import sys
from time import sleep
import os
#import phils_idea_for_into


# room design
def room():
    for i in '''
1 You awake in a dimly lit room, vaguely aware of a throbbing coming from
somewhere deep in your head, or is it below you in the house?
You push yourself up off the filthy rotting floorboards and hear the
scuttle of what you hope is a rat. There is enough moonlight filtering in
through the thick dusty curtains to make out what appears to be 4 doors.
Each scrawled with a letter in what you hope is not blood.
The wind howls and rattles the thin window panes but then you realise that
the howling is coming from inside the house. The dust picks up around you
and a show detaches itself from the rest.
The figure in front of you is that of a tall thin man wearing a beanie and
frameless glasses. You are frozen with fright. He bends, until his face is
inches from your own and he asks ***** There is another gust of wind and you
are unsure if the apparition of the man was a bad fever dream.
You look at the doors and choose which to go through. 

A,B,C or D
''':


        sys.stdout.write(i)
        sys.stdout.flush()
        sleep(.003)




#room()
#import questions.py
#print('Hello Phil')
room()
