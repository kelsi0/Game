# phil welsby - jan 15 2021
# names of people who made game on code nation
# intro to coding course - 11 to 15 january 2021
# ascii text by https://ascii.co.uk/text
# puffy font


import sys
from time import sleep
from ghost import ghost_art

def wiper():
    print('\n' *100)
wiper()
s = 0.001

presents = '''
 ___    ___    ___    ___    ___    _   _  _____  ___   
(  _`\ |  _`\ (  _`\ (  _`\ (  _`\ ( ) ( )(_   _)(  _`\ 
| |_) )| (_) )| (_(_)| (_(_)| (_(_)| `\| |  | |  | (_(_)
| ,__/'| ,  / |  _)_ `\__ \ |  _)_ | , ` |  | |  `\__ \ 
| |    | |\ \ | (_( )( )_) || (_( )| |`\ |  | |  ( )_) |
(_)    (_) (_)(____/'`\____)(____/'(_) (_)  (_)  `\____)
'''




for i in '''
8888ba.88ba     dP    dP     dP     .d888888  
88  `8b  `8b    88    88   .d8'    d8'    88  
88   88   88    88    88aaa8P'     88aaaaa88a 
88   88   88    88    88   `8b.    88     88  
88   88   88    88    88     88    88     88  
dP   dP   dP    dP    dP     dP    88     88  
''':
    sys.stdout.write(i)
    sys.stdout.flush
    sleep(s)
sleep(.5)
#print(mika)
for i in '''
dP     dP     88888888b    dP           .d88888b      88888888b    dP    dP 
88   .d8'     88           88           88.    "'     88           Y8.  .8P 
88aaa8P'     a88aaaa       88           `Y88888b.    a88aaaa        Y8aa8P  
88   `8b.     88           88                 `8b     88              88    
88     88     88           88           d8'   .8P     88              88    
dP     dP     88888888P    88888888P     Y88888P      88888888P       dP    
''':
    sys.stdout.write(i)
    sys.stdout.flush
    sleep(s)
sleep(.5)
#print(kelsey)
for i in '''
 888888ba     dP     dP     dP    dP        
 88    `8b    88     88     88    88        
a88aaaa8P'    88aaaaa88a    88    88        
 88           88     88     88    88        
 88           88     88     88    88        
 dP           dP     dP     dP    88888888P 
''':
    sys.stdout.write(i)
    sys.stdout.flush
    sleep(s)
sleep(.5)
#print(phil)
for i in '''
 88888888b     .d888888     dP     dP      .d888888     888888ba  
 88           d8'    88     88     88     d8'    88     88    `8b 
a88aaaa       88aaaaa88a    88aaaaa88a    88aaaaa88a    88     88 
 88           88     88     88     88     88     88     88     88 
 88           88     88     88     88     88     88     88    .8P 
 dP           88     88     dP     dP     88     88     8888888P  
''':
    sys.stdout.write(i)
    sys.stdout.flush
    sleep(s)
sleep(.5)
#print(fahad)
for i in '''

 .88888.      88888888b     .88888.      888888ba      .88888.      88888888b 
d8'   `88     88           d8'   `8b     88    `8b    d8'   `88     88        
88           a88aaaa       88     88    a88aaaa8P'    88           a88aaaa    
88   YP88     88           88     88     88   `8b.    88   YP88     88        
Y8.   .88     88           Y8.   .8P     88     88    Y8.   .88     88        
 `88888'      88888888P     `8888P'      dP     dP     `88888'      88888888P 
''':
    sys.stdout.write(i)
    sys.stdout.flush
    sleep(s)


sleep(2)
wiper()


for i in '''
 ___    ___    ___    ___    ___    _   _  _____ 
(  _`\ |  _`\ (  _`\ (  _`\ (  _`\ ( ) ( )(_   _)
| |_) )| (_) )| (_(_)| (_(_)| (_(_)| `\| |  | |  
| ,__/'| ,  / |  _)_ `\__ \ |  _)_ | , ` |  | |  
| |    | |\ \ | (_( )( )_) || (_( )| |`\ |  | |  
(_)    (_) (_)(____/'`\____)(____/'(_) (_)  (_)  
''':
    sys.stdout.write(i)
    sys.stdout.flush
    sleep(s)

sleep(1)


for i in '''
 ___    _   _  _____     _   _  _____  _____     ___    _____  ___    ___    ___   _____  _____  _  _   _  ___   
(  _`\ ( ) ( )(_   _)   ( ) ( )(  _  )(_   _)   (  _`\ (  _  )|  _`\ (  _`\ (  _`\(_   _)(_   _)(_)( ) ( )(  _`\ 
| (_) )| | | |  | |     | `\| || ( ) |  | |     | (_(_)| ( ) || (_) )| ( (_)| (_(_) | |    | |  | || `\| || ( (_)
|  _ <'| | | |  | |     | , ` || | | |  | |     |  _)  | | | || ,  / | |___ |  _)_  | |    | |  | || , ` || |___ 
| (_) )| (_) |  | |     | |`\ || (_) |  | |     | |    | (_) || |\ \ | (_, )| (_( ) | |    | |  | || |`\ || (_, )
(____/'(_____)  (_)     (_) (_)(_____)  (_)     (_)    (_____)(_) (_)(____/'(____/' (_)    (_)  (_)(_) (_)(____/'
''':
    sys.stdout.write(i)
    sys.stdout.flush
    sleep(s)


for i in '''
 _    _                                            _                                 _      ___ 
( )_ ( )                                          ( )     _                         (_ )  /'___)
| ,_)| |__     __       ___ ___     _ _   ___     | |__  (_)  ___ ___    ___    __   | | | (__  
| |  |  _ `\ /'__`\   /' _ ` _ `\ /'_` )/' _ `\   |  _ `\| |/' _ ` _ `\/',__) /'__`\ | | | ,__) 
| |_ | | | |(  ___/   | ( ) ( ) |( (_| || ( ) |   | | | || || ( ) ( ) |\__, \(  ___/ | | | |    
`\__)(_) (_)`\____)   (_) (_) (_)`\__,_)(_) (_)   (_) (_)(_)(_) (_) (_)(____/`\____)(___)(_)    
''':
    sys.stdout.write(i)
    sys.stdout.flush
    sleep(s)


for i in'''
 _____  _   _  ___       _____  _   _  ___       _____  _   _  ___       _____  _   _  _   _     _ 
(_   _)( ) ( )(  _`\    (  _  )( ) ( )(  _`\    (  _  )( ) ( )(  _`\    (  _  )( ) ( )( ) ( )   ( )
  | |  | |_| || (_(_)   | ( ) || `\| || (_(_)   | (_) || `\| || | ) |   | ( ) || `\| || | `\`\_/'/'
  | |  |  _  ||  _)_    | | | || , ` ||  _)_    |  _  || , ` || | | )   | | | || , ` || |  _`\ /'  
  | |  | | | || (_( )   | (_) || |`\ || (_( )   | | | || |`\ || |_) |   | (_) || |`\ || |_( )| |   
  (_)  (_) (_)(____/'   (_____)(_) (_)(____/'   (_) (_)(_) (_)(____/'   (_____)(_) (_)(____/'(_)   
''':
    sys.stdout.write(i)
    sys.stdout.flush
    sleep(s)


for i in'''
 _____  _____  _     _ 
(___  )(  _  )( )   ( )
    | || (_) |`\`\_/'/'
 _  | ||  _  |  `\ /'  
( )_| || | | |   | |   
`\___/'(_) (_)   (_)   
''':
    sys.stdout.write(i)
    sys.stdout.flush
    sleep(s)

#names = [[mika], [kelsey], [phil], [fahad], [george]]

sleep(1)
ghost_art()


#print(names[0])
#sleep(1)
#print(name[1])
#sleep(2)
#print(names[2])
#sleep(2)
#print(names[3])
#sleep(2)
#print(names[4])
#sleep(2)



