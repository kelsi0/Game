# phil welsby - 14 jan 2021
# winning end senario
# pep8 ran no errors

'''import modules - all used whilst developing
#from time import sleep
#import sys
#import webbrowser'''

# simple function to clear the screen by printing 100 newlines


def wiper():
    print('\n' * 100)


# clear screen
wiper()


def game_win():
    # text to screen
    for i in '''
    So considering you MUPPETS nicked all our code you ain't getting
    no fancy art...
    ''':

        sys.stdout.write(i)
        sys.stdout.flush()
        sleep(.003)

    # wait 5 seconds
    sleep(5)

    # clear screen
    wiper()

    print("         +-+      +")
    print("           | +-+  |   +-+")
    print("     +-+   |   |  |   |    +--+")
    print("       |   |   |  |   |    |")
    print("       |   |   |  |   |    |")
    print("   +---+---+---+--+---+----+----+")
    print("   |                            |")
    print("   |   +-------+     +-------+  |")
    print("+--+   |       |     |       |  +--+")
    print("|  |   |       |     |       |  |  |")
    print("|  |   |    +--+     |    +--+  |  |")
    print("+--+   |    |--|     |    |--|  +--+")
    print("   |   +-------+     +-------+  |")
    print("   |             +-+            |")
    print("   |             | |            |")
    print("   |             +-+            |")
    print("   |  +--+               +--+   |")
    print("   |    +-----------------+     |")
    print("   |                            |")
    print("   +----------------------------+")
    print("")

    sleep(1)

    # launch youtube vid
    webbrowser.open("https://www.youtube.com/watch?v=JYy69qOJWoM")


# game_win()
