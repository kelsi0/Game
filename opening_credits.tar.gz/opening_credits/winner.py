# phil welsby - 15 jam 2021
# main page to call all functions


from win import game_win
game_win()


from ghost import ghost_art
ghost_art()
